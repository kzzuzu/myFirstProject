package plants.exception;

public class VGBException extends Exception {
	public VGBException() {
		super();
	}

	public VGBException(String message, Throwable cause) {
		super(message, cause);
	}

	public VGBException(String message) {
		super(message);
	}

}
