SELECT * FROM vgb.products;

INSERT INTO `vgb`.`products` (`name`, `unit_price`, `stock`, `photo_url`) 
VALUES ('Java 7 教學手冊 第五版(附光碟)', '650', '5', 
	'https://im1.book.com.tw/image/getImage?i=https://www.books.com.tw/img/001/055/52/0010555220.jpg&w=374&h=374&v=5020f27b');
INSERT INTO `vgb`.`products` (`name`, `unit_price`, `stock`, `photo_url`, `discount`) 
VALUES ('Java SE 17 技術手冊', '680', '12', 
	'https://im1.book.com.tw/image/getImage?i=https://www.books.com.tw/img/001/092/37/0010923732.jpg&w=374&h=374&v=626bbe47', '21');
